package com.free.diary.main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.free.diary.R;


public class HomePageActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
    }
}
