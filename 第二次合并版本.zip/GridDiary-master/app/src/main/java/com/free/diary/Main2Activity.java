package com.free.diary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.free.diary.main.MemoActivity;
import com.free.diary.support.util.ActivityManager;
import com.free.diary.ui.activity.MainActivity;

public class Main2Activity extends AppCompatActivity {
    Button btDiary, btMemo;
    private static final int TIME_DIFF = 2000;
    private long mExitTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btDiary = (Button)findViewById(R.id.bt_to_diary);
        btMemo = (Button) findViewById(R.id.bt_to_memo);

        btDiary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        btMemo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,MemoActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                if (System.currentTimeMillis() - mExitTime > TIME_DIFF) {
                    Toast.makeText(Main2Activity.this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
                    mExitTime = System.currentTimeMillis();
                } else {
                    ActivityManager.removeAllActivity();
                    System.exit(0);
                }
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
