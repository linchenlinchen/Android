package com.free.diary.support.config;

/**
 * Created by tangqi on 16/5/20.
 */
public class KeyConfig {

    public static final String DIARY = "diary";
    public static final String GRID = "grid";
    public static final String SUBJECT = "subject";

    public static final String IS_ADD_GRID = "is_add_grid";
    public static final String CALENDAR_DAY = "calendar_day";
    public static final String DATE = "calendar_day";

}
