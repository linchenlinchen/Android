package com.free.diary;

import android.test.InstrumentationTestCase;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class ExampleUnitTest extends InstrumentationTestCase{

    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }
}