package com.free.diary.model.bean;

import java.io.Serializable;

/**
 * Created by tangqi on 16/5/20.
 */
public class BaseEntity implements Serializable {

}
