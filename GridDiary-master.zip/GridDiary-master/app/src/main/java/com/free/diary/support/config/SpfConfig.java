package com.free.diary.support.config;

/**
 * Created by tangqi on 16/5/19.
 */
public class SpfConfig {

    // 是否初始化问题库
    public static final String IS_INIT_SUBJECT = "is_init_subject";


}
